
void DelayUs2x(unsigned char t);
void DelayMs(unsigned char t);
