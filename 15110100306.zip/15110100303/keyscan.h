unsigned char KeyScan(void);

#define KeyPort P1 
