#include<reg52.h> 
#include"display.h"
void Display(unsigned char FirstBit,unsigned char Num)
{
	   DataPort=0;   
       LATCH1=1;     
       LATCH1=0;

       DataPort=dofly_WeiMa[i+FirstBit]; 
       LATCH2=1;     
       LATCH2=0;

       DataPort=TempData[i]; 
       LATCH1=1;    
       LATCH1=0;
       
	   i++;
       if(i==Num)
	      i=0;

}