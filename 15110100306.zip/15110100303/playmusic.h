
sbit beep=P2^4;
void PlayMusic();
