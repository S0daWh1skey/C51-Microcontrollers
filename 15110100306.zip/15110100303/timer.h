void Init_Timer0(void);

extern bit Time_seted_flag ;
extern bit Alarm_seted_flag;
extern unsigned char hour,minute,second;
extern bit UpdateTimeFlag;
extern unsigned char Ahour,Aminute,Asecond;
extern bit Cancel_Alarm_flag;
