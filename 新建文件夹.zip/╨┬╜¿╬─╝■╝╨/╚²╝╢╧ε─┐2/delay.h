void DelayUs2x(unsigned int t);
void DelayMs(unsigned int t);